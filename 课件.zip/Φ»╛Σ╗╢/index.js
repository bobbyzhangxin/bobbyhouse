 var title_nav = document.querySelector("#logo");


var aaa = "hahaha"




function changeFont () {
	var asd = "123";

	console.log(title_nav.innerHTML)
	var content = title_nav.innerHTML;
	title_nav.innerHTML = "chrome"
	//var content = tltle_nav.innerHTML;
};



title_nav.onclick = function() {
	console.log(asd);
};



function change () {

	var a = "aaaaaaaaa"

	function add () {

		var q = "qqqqqqq";

		alert(asd);

	};


	add ();


};



change ();